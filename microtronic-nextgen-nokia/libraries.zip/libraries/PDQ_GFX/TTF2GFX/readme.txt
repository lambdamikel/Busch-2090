Simple utility for create GFX fonts from TTF.
Major feature:
1. Allow create subset of chars (chech "only chars" check box)
2. Create packed font

Copyright (c) 2017 Andrey Belookon
http://dspview.com
ban.relayer@gmail.com