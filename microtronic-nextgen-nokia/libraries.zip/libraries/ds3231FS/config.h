#ifndef __config_h_
  #define __config_h_

  // comment this out if you need unixtime support
  // this will add around 500 bytes to your firmware (depend of the card)
  //#define CONFIG_UNIXTIME

#endif
