NOTE: This driver was based on Seeed TFT library ( https://github.com/Seeed-Studio/TFT_Touch_Shield_V1 ) and made to work with Adafruit style PDQ_GFX.  Thanks Seeed Studio and Adafruit!

It works with Seeed Studio Arduino Touch Shield V1.0 (which was also sold by Radio Shack).  Fast parallel LCD interface (not SPI).

See http://www.seeedstudio.com/wiki/2.8%27%27_TFT_Touch_Shield_V1.0
